do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "banhammer",
    "groupmanager",
    "msg-checks",
    "plugins",
    "tools",
    "me",
    "AAAA",
    "replay"
  },
  info_text = "تاج راسكم حسوني \n @Dev_Hussein5_6",
  moderation = {
    data = "./data/moderation.json"
  },
  sudo_users = {
    128897752,
    319244649,
    319244649,
    435245104,
    352465871
  }
}
return _
end